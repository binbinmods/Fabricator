# 0.5.0

Multipurpose Kit now reduces card costs

Reworked great minds thing alike to continually increase enchantment cost

Hopefully fixed issues with Overclocking desyncing with specific items.

# 0.4.0

Reworked Great Minds Think Alike to not break in multiplayer.

# 0.3.0

Fixed blue Torso Terror not targeting properly. Fixed target locked applying block and taunt when played in addition to when activated.

# 0.2.0

Fixed Overclocking and Great Minds Think Alike. Still minor bugs with Great Minds Think Alike

# 0.1.1

First batch of bug fixes

# 0.1.0

Initial pre-release.