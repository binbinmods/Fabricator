# 1.1.0

Update for AtO v1.6.22

# 1.0.1

Fixed OC crash

Cardback no longer shares

# 1.0.0

Initial Release

# 0.8.0

Great Minds Think Alike capped at 3x/Round now

Great Minds Think Alike no longer triggers when dead

# 0.7.0

Great Minds Think Alike capped at 3x/turn

Think Fast now procs 3 times at all levels.

# 0.6.0

Fixed Mental Mutilator improper Id

Defence Drone can now target anyone.

Slimmed model down a bit.

Rework for Great Minds Think Alike

# 0.5.0

Multipurpose Kit now reduces card costs

Reworked great minds thing alike to continually increase enchantment cost

Hopefully fixed issues with Overclocking desyncing with specific items.

# 0.4.0

Reworked Great Minds Think Alike to not break in multiplayer.

# 0.3.0

Fixed blue Torso Terror not targeting properly. Fixed target locked applying block and taunt when played in addition to when activated.

# 0.2.0

Fixed Overclocking and Great Minds Think Alike. Still minor bugs with Great Minds Think Alike

# 0.1.1

First batch of bug fixes

# 0.1.0

Initial pre-release.
